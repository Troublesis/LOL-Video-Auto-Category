import os
import shutil
## import functions / library from files

# import champion dictionary
from championDictionary import championDict
from functionsLibrary import lolDetectGameMode
from functionsLibrary import lolChampionIconCrop
from functionsLibrary import lolDetectChampion

championIconFolder = os.path.dirname(os.path.abspath( __file__ ))+'/'+'Champion Icon/'

# initial root folder setting

# input the root folder path of where you store all of your recorded League of Legends videos
inputSourceFolder         = input('Please enter the source folder path (Sample: F:\bambo\Videos\Overwolf\Game Summary\League of Legends): ')
gameModeDestination       = input('Please enter the new folder path where you want to store League of Legends Game Videos (Sample: F:/bambo/Videos/Overwolf/Game Summary/): ')
normalGameModeDestination = gameModeDestination + 'Normal/'
aramlGameModeDestination  = gameModeDestination + 'ARAM/'
# enable the following line and comment the upper line if you don't want to enter the folder path every time
# inputSourceFolder = 'F:\\bambo\\Videos\\Overwolf\\Game Summary\\League of Legends'
rootFolder = inputSourceFolder.replace('\\','/')+'/'
# return the correct format for root folder path
print('Your root folder is: ',rootFolder)
print('========================================\n')

##################################################################


folderList = os.listdir(rootFolder)
print('Folders List for your root folder is: \n',folderList)
print('========================================\n')
# source = os.path.dirname(os.path.abspath( __file__ ))+'/'

# undefined champion icon index number for rename the undefined champion icon images cropped from the video frame
undefinedChampionIndex = 0

# loop to check each folder inside the root folder
for folderName in folderList:
    # get the folder path of each folder inside the root folder
    source = rootFolder+folderName+'/'
    print('===> Checking folder: '+source)

    # fix: still working on these lines... need to fix if there was no file found in the selected folder
    
    # select a video inside the folder
    try:
        videoName = os.listdir(source)[2]
    except WindowsError:
        videoName = os.listdir(source)[3]

    # fix: currently the sorted video folders name is set to selected video file name, need to change it to name of the folder where stores these videos
    # get the video file name length sample: League of Legends 03-12-2020 22-02-17-568.mp4
    videoNameLength = len(videoName)
    # slice the video name - delete .mp4    ===> set this as folder name 
    videoFolderName = videoName[0:videoNameLength-4]
    # get the grass pixel color percentage from the video frame to determine game mode
    # lolDetectGameMode function will capture a video frame and save the image in video folder as frame.jpg
    pixelColorPercentage = lolDetectGameMode(source,videoName)

    # set the crop coordinates in order to crop a champion icon image from the captured champion frame
    left = 385
    top = 643
    right = 433
    bottom = 689

    # lolChampionIconCrop will crop a champion icon image from frame.jpg and save it in video folder
    lolChampionIconCrop(source, left, top, right, bottom)
    # get the champion icon image file path
    championIconFile = source+'championIcon.jpg'
    print('===> championIcon.jpg stored at: '+championIconFile)
    # get the video frame image file path
    videoFrame = source+'frame.jpg'
    print('===> frame.jpg        stored at: '+videoFrame+'\n')

    # set inital value of variable championFound as 0 for break a loop when champion detected
    championFound = 0
    # set inital value of champion skin icon index as 0 for counting how many skins for each champion stored in our champion dictionary
    championSkinIconIndex = 0
    # get the totol number of champion skins
    totalNumberOfSkins = len(championDict)

    # loop to check all of champion name in champion dictionary
    for championName in championDict:
        # get the current name of champion skin in the loop
        nameOfChampionSkins = len(championDict[championName])
        # loop to check all of skins for each champion
        for skin in championDict[championName]:
            # when champion is found, break the loop
            if championFound > 0:
                # championFound = 0
                break
            # print current comparing skin name           
            skinName = championDict[championName][championSkinIconIndex]
            print('===> Comparing '+skinName)
            # when game mode is normal
            if pixelColorPercentage > 5:
                # set normal game video store location
                # normalGameModeDestination = 'F:/bambo/Videos/Overwolf/Game Summary/Normal/'
                # run function lolDetectChampion 
                championFound = lolDetectChampion(championIconFolder,source,0.9,'normal',championName,skinName,normalGameModeDestination,videoFolderName)
                # when game mode is aram
            elif pixelColorPercentage < 5:
                # set normal game video store location
                # aramGameModeDestination = 'F:/bambo/Videos/Overwolf/Game Summary/ARAM/'
                # run function lolDetectChampion 
                championFound = lolDetectChampion(championIconFolder,source,0.9,'aram',championName,skinName,aramGameModeDestination,videoFolderName)
            # fix: these lines might have some issue. 
            # when all of champion skins have been checked move the undefined champion icon
            if championName == list(championDict.keys())[-1]:
                if skinName == championDict[list(championDict.keys())[-1]][len(championDict[championName])-1]:
                    try:
                        os.rename(championIconFile,championIconFolder+'undefinedChampion'+str(undefinedChampionIndex)+'.jpg')
                        os.rename(videoFrame,championIconFolder+'undefinedChampionFrame'+str(undefinedChampionIndex)+'.jpg')
                        print( '===> Undefined champion icon moved to: ',championIconFolder)
                        print('\n\n------------------------->')                        
                    except WindowsError:
                        os.remove(championIconFolder+'undefinedChampion'+str(undefinedChampionIndex)+'.jpg')
                        os.remove(championIconFolder+'undefinedChampionFrame'+str(undefinedChampionIndex)+'.jpg')
                        os.rename(championIconFile,championIconFolder+'undefinedChampion'+str(undefinedChampionIndex)+'.jpg')
                        os.rename(videoFrame,championIconFolder+'undefinedChampionFrame'+str(undefinedChampionIndex)+'.jpg')
                    undefinedChampionIndex += 1
                    print( '===> Undefined champion icon moved to: ',championIconFolder)
                    print('\n\n------------------------->')    
                   
            championSkinIconIndex += 1     

        championSkinIconIndex = 0 
wait = input('wait')

